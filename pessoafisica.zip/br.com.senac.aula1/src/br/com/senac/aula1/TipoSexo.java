package br.com.senac.aula1;

public enum TipoSexo {
    MASCULINO,
    FEMININO,
    OUTROS;
}
