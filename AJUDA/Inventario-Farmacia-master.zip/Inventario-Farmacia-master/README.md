Un programa para manejar inventario de medicamentos, laboratorios y proveedores que posee una farmacia. Hecho con componentes swing de java (Java)
