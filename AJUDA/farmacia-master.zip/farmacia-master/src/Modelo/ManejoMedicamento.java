package Modelo;
/**
 *
 * @author José Diaz
 */
public class ManejoMedicamento {
   
}
