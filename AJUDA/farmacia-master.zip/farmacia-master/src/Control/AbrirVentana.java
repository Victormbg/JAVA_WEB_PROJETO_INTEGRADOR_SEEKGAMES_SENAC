package Control;
/**
 *
 * @author José Diaz
 */
public interface AbrirVentana {
    
    public abstract void abrirVentana();
}
