package Control;
/**
 *
 * @author José Diaz
 */
public interface CerrarVentana {
    
    public abstract void cerrarVentana();
}