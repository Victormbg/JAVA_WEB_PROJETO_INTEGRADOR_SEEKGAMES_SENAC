package Control;
/**
 *
 * @author José Diaz
 */
public interface SeleccionarDeseleccionar {
    
    public abstract void seleccionar();
    
    public abstract void deseleccionar();    
}
