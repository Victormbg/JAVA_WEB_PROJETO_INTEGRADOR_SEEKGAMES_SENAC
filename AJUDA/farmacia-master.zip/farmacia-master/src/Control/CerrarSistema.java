package Control;
/**
 *
 * @author José Diaz
 */
public interface CerrarSistema {
    
    public abstract void cerrarSistema();
}
