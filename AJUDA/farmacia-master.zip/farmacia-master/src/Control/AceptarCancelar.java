package Control;
/**
 *
 * @author José Diaz
 */
public interface AceptarCancelar {    
    
    public abstract void aceptar();
    
    public abstract void cancelar();
}