package com.jdenner.control;

public interface Controller {

    public void editar(int codigo);

    public void excluir(int codigo);

}
