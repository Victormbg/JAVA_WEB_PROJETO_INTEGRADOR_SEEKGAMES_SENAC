<h1>Sistemas de Vendas FX</h1>
<p>Autor: Juliano Denner da Rocha<br>E-mail: jdenner@outlook.com</p>
<p>Aplicação desenvolvida como material de apoio ao aprendizado de programação JavaFX. É fornecida gratuitamente "no estado em que se encontra", isentando o autor de qualquer garantia ou danos que possam resultar do uso da mesma.</p>
<p>Ferramentas utilizadas:
  <ul>
    <li>Java 1.8.0 u65</li>
    <li>NetBeans IDE 8.1</li>
    <li>MySQL Server 5.1.53-community</li>
    <li>MySQL Connector JDBC 5.1.23</li>
    <li>Windows 7 Professional sp1</li>
  </ul>
</p>
<p>Pré-visualização:</p>
<img src="http://jdenner.com/github/java-sistema-vendas-fx.png" alt="Sistema executando">
